namespace WaterSewageManagementSystem.Forms.MaintenanceEngineer
{
    partial class MaintenanceDashboardForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.panelHeader             = new System.Windows.Forms.Panel();
            this.lblTitle                = new System.Windows.Forms.Label();
            this.lblWelcome              = new System.Windows.Forms.Label();
            this.btnAssignedComplaints   = new System.Windows.Forms.Button();
            this.btnMaintenanceTasks     = new System.Windows.Forms.Button();
            this.btnRepairProgress       = new System.Windows.Forms.Button();
            this.btnVisitDate            = new System.Windows.Forms.Button();
            this.btnInspectionNotes      = new System.Windows.Forms.Button();
            this.btnCompletionReport     = new System.Windows.Forms.Button();
            this.btnWaterQuality         = new System.Windows.Forms.Button();
            this.btnProfile              = new System.Windows.Forms.Button();
            this.btnLogout               = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(860, 560);
            this.Text = "Maintenance Engineer Dashboard - WASA Management System";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.FromArgb(240, 244, 248);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle; this.MaximizeBox = false;

            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(46, 125, 50);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top; this.panelHeader.Height = 70;
            this.lblTitle.Text = "WASA Management System"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White; this.lblTitle.Location = new System.Drawing.Point(20, 10); this.lblTitle.Size = new System.Drawing.Size(420, 30);
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 10F); this.lblWelcome.ForeColor = System.Drawing.Color.LightGreen;
            this.lblWelcome.Location = new System.Drawing.Point(20, 42); this.lblWelcome.Size = new System.Drawing.Size(420, 22);
            this.panelHeader.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblWelcome });

            string[] labels = { "Assigned Complaints", "Maintenance Tasks", "Update Repair Progress", "Set Visit Date", "Inspection Notes", "Completion Report", "Water Quality Issue", "My Profile", "Logout" };
            System.Windows.Forms.Button[] btns = { btnAssignedComplaints, btnMaintenanceTasks, btnRepairProgress, btnVisitDate, btnInspectionNotes, btnCompletionReport, btnWaterQuality, btnProfile, btnLogout };
            System.Drawing.Color[] colors = {
                System.Drawing.Color.FromArgb(46,125,50),   System.Drawing.Color.FromArgb(0,105,92),
                System.Drawing.Color.FromArgb(230,81,0),    System.Drawing.Color.FromArgb(0,96,100),
                System.Drawing.Color.FromArgb(106,27,154),  System.Drawing.Color.FromArgb(21,101,192),
                System.Drawing.Color.FromArgb(183,28,28),   System.Drawing.Color.FromArgb(33,33,33),
                System.Drawing.Color.FromArgb(136,14,79)
            };
            System.EventHandler[] handlers = {
                btnAssignedComplaints_Click, btnMaintenanceTasks_Click, btnRepairProgress_Click,
                btnVisitDate_Click, btnInspectionNotes_Click, btnCompletionReport_Click,
                btnWaterQuality_Click, btnProfile_Click, btnLogout_Click };

            for (int i = 0; i < btns.Length; i++)
            {
                int col = i % 3, row = i / 3;
                btns[i].Text = labels[i]; btns[i].Location = new System.Drawing.Point(50 + col * 265, 90 + row * 130);
                btns[i].Size = new System.Drawing.Size(235, 100); btns[i].Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
                btns[i].ForeColor = System.Drawing.Color.White; btns[i].BackColor = colors[i];
                btns[i].FlatStyle = System.Windows.Forms.FlatStyle.Flat; btns[i].FlatAppearance.BorderSize = 0;
                btns[i].Cursor = System.Windows.Forms.Cursors.Hand; btns[i].Click += handlers[i];
                this.Controls.Add(btns[i]);
            }

            this.Controls.Add(this.panelHeader);
            this.panelHeader.ResumeLayout(false);
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.Panel  panelHeader;
        private System.Windows.Forms.Label  lblTitle, lblWelcome;
        private System.Windows.Forms.Button btnAssignedComplaints, btnMaintenanceTasks, btnRepairProgress;
        private System.Windows.Forms.Button btnVisitDate, btnInspectionNotes, btnCompletionReport;
        private System.Windows.Forms.Button btnWaterQuality, btnProfile, btnLogout;
    }
}
