using System;
using System.Windows.Forms;
using WaterSewageManagementSystem.Helpers;
using WaterSewageManagementSystem.Forms.Common;

namespace WaterSewageManagementSystem.Forms.Admin
{
    public partial class AdminDashboardForm : Form
    {
        public AdminDashboardForm()
        {
            InitializeComponent();
            lblWelcome.Text = "Welcome, " + SessionManager.CurrentUser.FullName;
        }

        private void btnManageUsers_Click(object sender, EventArgs e) => new ManageUsersForm().ShowDialog();
        private void btnApproveEmployees_Click(object sender, EventArgs e) => new ApproveEmployeesForm().ShowDialog();
        private void btnAssignComplaints_Click(object sender, EventArgs e) => new AssignComplaintsForm().ShowDialog();
        private void btnNotices_Click(object sender, EventArgs e) => new NoticeManagementForm().ShowDialog();
        private void btnReports_Click(object sender, EventArgs e) => new SystemReportForm().ShowDialog();
        private void btnProfile_Click(object sender, EventArgs e) => new ProfileForm().ShowDialog();
        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageHelper.ShowConfirm("Are you sure you want to logout?") == DialogResult.Yes)
            {
                SessionManager.Logout();
                this.Close();
            }
        }
    }
}
