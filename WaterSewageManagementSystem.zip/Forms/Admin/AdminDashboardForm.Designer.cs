namespace WaterSewageManagementSystem.Forms.Admin
{
    partial class AdminDashboardForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.panelHeader  = new System.Windows.Forms.Panel();
            this.lblTitle     = new System.Windows.Forms.Label();
            this.lblWelcome   = new System.Windows.Forms.Label();
            this.panelMenu    = new System.Windows.Forms.Panel();
            this.btnManageUsers = new System.Windows.Forms.Button();
            this.btnApproveEmployees = new System.Windows.Forms.Button();
            this.btnAssignComplaints = new System.Windows.Forms.Button();
            this.btnNotices   = new System.Windows.Forms.Button();
            this.btnReports   = new System.Windows.Forms.Button();
            this.btnProfile   = new System.Windows.Forms.Button();
            this.btnLogout    = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.SuspendLayout();

            this.ClientSize    = new System.Drawing.Size(800, 550);
            this.Text          = "Admin Dashboard - WASA Management System";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor     = System.Drawing.Color.FromArgb(240, 244, 248);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox   = false;

            // Header
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(13, 71, 161);
            this.panelHeader.Dock      = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height    = 70;
            this.lblTitle.Text      = "WASA Management System";
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location  = new System.Drawing.Point(20, 10);
            this.lblTitle.Size      = new System.Drawing.Size(400, 30);
            this.lblWelcome.Font      = new System.Drawing.Font("Segoe UI", 10F);
            this.lblWelcome.ForeColor = System.Drawing.Color.LightBlue;
            this.lblWelcome.Location  = new System.Drawing.Point(20, 42);
            this.lblWelcome.Size      = new System.Drawing.Size(400, 22);
            this.panelHeader.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblWelcome });

            // Buttons
            string[] labels = { "Manage Users", "Approve Employees", "Assign Complaints", "Notice Management", "System Reports", "My Profile", "Logout" };
            System.Windows.Forms.Button[] btns = { btnManageUsers, btnApproveEmployees, btnAssignComplaints, btnNotices, btnReports, btnProfile, btnLogout };
            System.Drawing.Color[] colors = {
                System.Drawing.Color.FromArgb(21,101,192), System.Drawing.Color.FromArgb(46,125,50),
                System.Drawing.Color.FromArgb(230,81,0),   System.Drawing.Color.FromArgb(106,27,154),
                System.Drawing.Color.FromArgb(0,96,100),   System.Drawing.Color.FromArgb(33,33,33),
                System.Drawing.Color.FromArgb(183,28,28)
            };

            System.EventHandler[] handlers = {
                btnManageUsers_Click, btnApproveEmployees_Click, btnAssignComplaints_Click,
                btnNotices_Click, btnReports_Click, btnProfile_Click, btnLogout_Click };

            for (int i = 0; i < btns.Length; i++)
            {
                int col = i % 3, row = i / 3;
                btns[i].Text      = labels[i];
                btns[i].Location  = new System.Drawing.Point(50 + col * 235, 100 + row * 130);
                btns[i].Size      = new System.Drawing.Size(200, 100);
                btns[i].Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
                btns[i].ForeColor = System.Drawing.Color.White;
                btns[i].BackColor = colors[i];
                btns[i].FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                btns[i].FlatAppearance.BorderSize = 0;
                btns[i].Cursor    = System.Windows.Forms.Cursors.Hand;
                btns[i].Click    += handlers[i];
                this.Controls.Add(btns[i]);
            }

            this.Controls.Add(this.panelHeader);
            this.panelHeader.ResumeLayout(false);
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel  panelHeader, panelMenu;
        private System.Windows.Forms.Label  lblTitle, lblWelcome;
        private System.Windows.Forms.Button btnManageUsers, btnApproveEmployees, btnAssignComplaints;
        private System.Windows.Forms.Button btnNotices, btnReports, btnProfile, btnLogout;
    }
}
