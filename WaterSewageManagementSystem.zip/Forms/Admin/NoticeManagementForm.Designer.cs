namespace WaterSewageManagementSystem.Forms.Admin
{
    partial class NoticeManagementForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle   = new System.Windows.Forms.Label();
            this.lblNewNotice = new System.Windows.Forms.Label();
            this.lblNTitle  = new System.Windows.Forms.Label(); this.txtTitle = new System.Windows.Forms.TextBox();
            this.lblDesc    = new System.Windows.Forms.Label(); this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblArea    = new System.Windows.Forms.Label(); this.txtArea = new System.Windows.Forms.TextBox();
            this.lblType    = new System.Windows.Forms.Label(); this.cmbType = new System.Windows.Forms.ComboBox();
            this.btnPublish = new System.Windows.Forms.Button();
            this.dgvNotices = new System.Windows.Forms.DataGridView();
            this.btnDelete  = new System.Windows.Forms.Button();
            this.btnClose   = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)this.dgvNotices).BeginInit();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(950, 600); this.Text = "Notice Management";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen; this.BackColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            this.lblTitle.Text = "Notice Management"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(106,27,154); this.lblTitle.Location = new System.Drawing.Point(20, 10); this.lblTitle.Size = new System.Drawing.Size(260, 30);

            this.lblNewNotice.Text = "Publish New Notice"; this.lblNewNotice.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblNewNotice.ForeColor = System.Drawing.Color.DimGray; this.lblNewNotice.Location = new System.Drawing.Point(20, 50); this.lblNewNotice.Size = new System.Drawing.Size(200, 22);

            R(this.lblNTitle, "Title *", this.txtTitle, 20, 180, 400, 80, false);
            this.txtDescription.Multiline = true; this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            R(this.lblDesc, "Description *", this.txtDescription, 20, 180, 400, 115, false); this.txtDescription.Height = 55;
            R(this.lblArea, "Area", this.txtArea, 20, 180, 200, 180, false);
            this.lblType.Text = "Type"; this.lblType.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.lblType.Location = new System.Drawing.Point(20, 213); this.lblType.Size = new System.Drawing.Size(155, 20);
            this.cmbType.Location = new System.Drawing.Point(180, 211); this.cmbType.Size = new System.Drawing.Size(180, 26); this.cmbType.Font = new System.Drawing.Font("Segoe UI", 10F); this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.Items.AddRange(new object[] { "General", "Maintenance", "Emergency" }); this.cmbType.SelectedIndex = 0;

            this.btnPublish.Text = "Publish Notice"; this.btnPublish.Location = new System.Drawing.Point(20, 250); this.btnPublish.Size = new System.Drawing.Size(150, 36);
            this.btnPublish.BackColor = System.Drawing.Color.FromArgb(106,27,154); this.btnPublish.ForeColor = System.Drawing.Color.White;
            this.btnPublish.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnPublish.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnPublish.FlatAppearance.BorderSize = 0; this.btnPublish.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPublish.Click += new System.EventHandler(this.btnPublish_Click);

            this.dgvNotices.Location = new System.Drawing.Point(20, 305); this.dgvNotices.Size = new System.Drawing.Size(910, 240);
            this.dgvNotices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNotices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNotices.ReadOnly = true; this.dgvNotices.AllowUserToAddRows = false;
            this.dgvNotices.BackgroundColor = System.Drawing.Color.White; this.dgvNotices.RowHeadersVisible = false;
            this.dgvNotices.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(106,27,154);
            this.dgvNotices.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvNotices.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvNotices.EnableHeadersVisualStyles = false;

            this.btnDelete.Text = "Delete Selected"; this.btnDelete.Location = new System.Drawing.Point(20, 558); this.btnDelete.Size = new System.Drawing.Size(150, 32);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(183,28,28); this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnDelete.FlatAppearance.BorderSize = 0; this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            this.btnClose.Text = "Close"; this.btnClose.Location = new System.Drawing.Point(840, 558); this.btnClose.Size = new System.Drawing.Size(90, 32);
            this.btnClose.BackColor = System.Drawing.Color.Gray; this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnClose.FlatAppearance.BorderSize = 0; this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblNewNotice, this.lblNTitle, this.txtTitle, this.lblDesc, this.txtDescription, this.lblArea, this.txtArea, this.lblType, this.cmbType, this.btnPublish, this.dgvNotices, this.btnDelete, this.btnClose });
            ((System.ComponentModel.ISupportInitialize)this.dgvNotices).EndInit();
            this.ResumeLayout(false);
        }
        private void R(System.Windows.Forms.Label lbl, string text, System.Windows.Forms.TextBox txt, int lx, int tx, int w, int y, bool pw)
        {
            lbl.Text = text; lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); lbl.Location = new System.Drawing.Point(lx, y+3); lbl.Size = new System.Drawing.Size(155, 20);
            txt.Location = new System.Drawing.Point(tx, y); txt.Size = new System.Drawing.Size(w, 26); txt.Font = new System.Drawing.Font("Segoe UI", 10F); txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            if (pw) txt.PasswordChar = '*';
        }
        private System.Windows.Forms.Label lblTitle, lblNewNotice, lblNTitle, lblDesc, lblArea, lblType;
        private System.Windows.Forms.TextBox txtTitle, txtDescription, txtArea;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Button btnPublish, btnDelete, btnClose;
        private System.Windows.Forms.DataGridView dgvNotices;
    }
}
