namespace WaterSewageManagementSystem.Forms.Customer
{
    partial class ConnectionApplicationForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle   = new System.Windows.Forms.Label();
            this.lblInfo    = new System.Windows.Forms.Label();
            this.lblStep1   = new System.Windows.Forms.Label();
            this.lblStep2   = new System.Windows.Forms.Label();
            this.lblStep3   = new System.Windows.Forms.Label();
            this.lblStep4   = new System.Windows.Forms.Label();
            this.btnApply   = new System.Windows.Forms.Button();
            this.btnClose   = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(520, 380); this.Text = "Apply for New Connection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen; this.BackColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            this.lblTitle.Text = "New Connection Application"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(46,125,50); this.lblTitle.Location = new System.Drawing.Point(80, 15); this.lblTitle.Size = new System.Drawing.Size(360, 28);

            this.lblInfo.Text = "Submitting this application will request a new water/sewage connection.\nA Service Officer will review your application and contact you.";
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9F); this.lblInfo.ForeColor = System.Drawing.Color.DimGray;
            this.lblInfo.Location = new System.Drawing.Point(30, 55); this.lblInfo.Size = new System.Drawing.Size(460, 45);

            string[] steps = {
                "Step 1: Submit this application form",
                "Step 2: Service Officer will verify your documents",
                "Step 3: Application will be approved or rejected",
                "Step 4: Installation will be scheduled if approved"
            };
            System.Windows.Forms.Label[] stepLabels = { lblStep1, lblStep2, lblStep3, lblStep4 };
            System.Drawing.Color[] stepColors = {
                System.Drawing.Color.FromArgb(21,101,192), System.Drawing.Color.FromArgb(230,81,0),
                System.Drawing.Color.FromArgb(46,125,50),  System.Drawing.Color.FromArgb(106,27,154)
            };
            for (int i = 0; i < stepLabels.Length; i++)
            {
                stepLabels[i].Text      = steps[i];
                stepLabels[i].Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
                stepLabels[i].ForeColor = stepColors[i];
                stepLabels[i].Location  = new System.Drawing.Point(30, 115 + i * 42);
                stepLabels[i].Size      = new System.Drawing.Size(460, 28);
            }

            this.btnApply.Text = "Submit Application"; this.btnApply.Location = new System.Drawing.Point(30, 305); this.btnApply.Size = new System.Drawing.Size(200, 42);
            this.btnApply.BackColor = System.Drawing.Color.FromArgb(46,125,50); this.btnApply.ForeColor = System.Drawing.Color.White;
            this.btnApply.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnApply.FlatAppearance.BorderSize = 0; this.btnApply.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);

            this.btnClose.Text = "Close"; this.btnClose.Location = new System.Drawing.Point(390, 305); this.btnClose.Size = new System.Drawing.Size(100, 42);
            this.btnClose.BackColor = System.Drawing.Color.Gray; this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnClose.FlatAppearance.BorderSize = 0; this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblInfo, this.lblStep1, this.lblStep2, this.lblStep3, this.lblStep4, this.btnApply, this.btnClose });
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.Label lblTitle, lblInfo, lblStep1, lblStep2, lblStep3, lblStep4;
        private System.Windows.Forms.Button btnApply, btnClose;
    }
}
