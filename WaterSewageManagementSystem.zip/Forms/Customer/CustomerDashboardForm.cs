using System;
using System.Windows.Forms;
using WaterSewageManagementSystem.Helpers;
using WaterSewageManagementSystem.Forms.Common;

namespace WaterSewageManagementSystem.Forms.Customer
{
    public partial class CustomerDashboardForm : Form
    {
        public CustomerDashboardForm()
        {
            InitializeComponent();
            lblWelcome.Text = "Welcome, " + SessionManager.CurrentUser.FullName;
        }

        private void btnCurrentBill_Click(object sender, EventArgs e)    => new CurrentBillForm().ShowDialog();
        private void btnBillHistory_Click(object sender, EventArgs e)     => new BillHistoryForm().ShowDialog();
        private void btnDispute_Click(object sender, EventArgs e)         => new SubmitBillDisputeForm().ShowDialog();
        private void btnComplaint_Click(object sender, EventArgs e)       => new SubmitComplaintForm().ShowDialog();
        private void btnTrackComplaint_Click(object sender, EventArgs e)  => new TrackComplaintForm().ShowDialog();
        private void btnConnection_Click(object sender, EventArgs e)      => new ConnectionApplicationForm().ShowDialog();
        private void btnTrackApp_Click(object sender, EventArgs e)        => new TrackApplicationForm().ShowDialog();
        private void btnNotices_Click(object sender, EventArgs e)         => new ViewNoticesForm().ShowDialog();
        private void btnProfile_Click(object sender, EventArgs e)         => new ProfileForm().ShowDialog();
        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageHelper.ShowConfirm("Are you sure you want to logout?") == DialogResult.Yes)
            {
                SessionManager.Logout();
                this.Close();
            }
        }
    }
}
