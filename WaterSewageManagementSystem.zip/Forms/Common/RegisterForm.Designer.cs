namespace WaterSewageManagementSystem.Forms.Common
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle    = new System.Windows.Forms.Label();
            this.lblName     = new System.Windows.Forms.Label();
            this.txtName     = new System.Windows.Forms.TextBox();
            this.lblEmail    = new System.Windows.Forms.Label();
            this.txtEmail    = new System.Windows.Forms.TextBox();
            this.lblPhone    = new System.Windows.Forms.Label();
            this.txtPhone    = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblConfirm  = new System.Windows.Forms.Label();
            this.txtConfirm  = new System.Windows.Forms.TextBox();
            this.lblRole     = new System.Windows.Forms.Label();
            this.cmbRole     = new System.Windows.Forms.ComboBox();
            this.lblAddress  = new System.Windows.Forms.Label();
            this.txtAddress  = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnCancel   = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClientSize    = new System.Drawing.Size(480, 530);
            this.Text          = "Register New Account";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor     = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox   = false;

            int lx = 30, tx = 180, w = 260, ly = 20;

            this.lblTitle.Text     = "Create Account";
            this.lblTitle.Font     = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(13, 71, 161);
            this.lblTitle.Location = new System.Drawing.Point(140, ly);
            this.lblTitle.Size     = new System.Drawing.Size(200, 30);

            int y = 70;
            AddLabel(this.lblName, "Full Name *", lx, y);
            AddTextBox(this.txtName, tx, y, w);

            y += 45;
            AddLabel(this.lblEmail, "Email *", lx, y);
            AddTextBox(this.txtEmail, tx, y, w);

            y += 45;
            AddLabel(this.lblPhone, "Phone *", lx, y);
            AddTextBox(this.txtPhone, tx, y, w);

            y += 45;
            AddLabel(this.lblPassword, "Password *", lx, y);
            this.txtPassword.Location     = new System.Drawing.Point(tx, y);
            this.txtPassword.Size         = new System.Drawing.Size(w, 26);
            this.txtPassword.Font         = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.BorderStyle  = System.Windows.Forms.BorderStyle.FixedSingle;

            y += 45;
            AddLabel(this.lblConfirm, "Confirm Password *", lx, y);
            this.txtConfirm.Location     = new System.Drawing.Point(tx, y);
            this.txtConfirm.Size         = new System.Drawing.Size(w, 26);
            this.txtConfirm.Font         = new System.Drawing.Font("Segoe UI", 10F);
            this.txtConfirm.PasswordChar = '*';
            this.txtConfirm.BorderStyle  = System.Windows.Forms.BorderStyle.FixedSingle;

            y += 45;
            AddLabel(this.lblRole, "Register As *", lx, y);
            this.cmbRole.Location     = new System.Drawing.Point(tx, y);
            this.cmbRole.Size         = new System.Drawing.Size(w, 26);
            this.cmbRole.Font         = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRole.Items.AddRange(new object[] { "Customer", "ServiceOfficer", "MaintenanceEngineer" });
            this.cmbRole.SelectedIndex = 0;

            y += 45;
            AddLabel(this.lblAddress, "Address", lx, y);
            AddTextBox(this.txtAddress, tx, y, w);

            y += 55;
            this.btnRegister.Text      = "REGISTER";
            this.btnRegister.Location  = new System.Drawing.Point(tx, y);
            this.btnRegister.Size      = new System.Drawing.Size(125, 38);
            this.btnRegister.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(13, 71, 161);
            this.btnRegister.ForeColor = System.Drawing.Color.White;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister.FlatAppearance.BorderSize = 0;
            this.btnRegister.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.Click    += new System.EventHandler(this.btnRegister_Click);

            this.btnCancel.Text      = "Cancel";
            this.btnCancel.Location  = new System.Drawing.Point(tx + 135, y);
            this.btnCancel.Size      = new System.Drawing.Size(125, 38);
            this.btnCancel.Font      = new System.Drawing.Font("Segoe UI", 10F);
            this.btnCancel.BackColor = System.Drawing.Color.LightGray;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.Click    += new System.EventHandler(this.btnCancel_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblTitle, this.lblName, this.txtName, this.lblEmail, this.txtEmail,
                this.lblPhone, this.txtPhone, this.lblPassword, this.txtPassword,
                this.lblConfirm, this.txtConfirm, this.lblRole, this.cmbRole,
                this.lblAddress, this.txtAddress, this.btnRegister, this.btnCancel });

            this.ResumeLayout(false);
        }

        private void AddLabel(System.Windows.Forms.Label lbl, string text, int x, int y)
        {
            lbl.Text     = text;
            lbl.Font     = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            lbl.Location = new System.Drawing.Point(x, y + 3);
            lbl.Size     = new System.Drawing.Size(145, 20);
        }

        private void AddTextBox(System.Windows.Forms.TextBox txt, int x, int y, int w)
        {
            txt.Location    = new System.Drawing.Point(x, y);
            txt.Size        = new System.Drawing.Size(w, 26);
            txt.Font        = new System.Drawing.Font("Segoe UI", 10F);
            txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        }

        private System.Windows.Forms.Label    lblTitle, lblName, lblEmail, lblPhone, lblPassword, lblConfirm, lblRole, lblAddress;
        private System.Windows.Forms.TextBox  txtName, txtEmail, txtPhone, txtPassword, txtConfirm, txtAddress;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Button   btnRegister, btnCancel;
    }
}
