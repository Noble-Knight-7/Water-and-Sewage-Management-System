namespace WaterSewageManagementSystem.Forms.Common
{
    partial class ProfileForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label(); this.lblRole = new System.Windows.Forms.Label(); this.lblStatus = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label(); this.txtName = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label(); this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label(); this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label(); this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button(); this.btnChangePassword = new System.Windows.Forms.Button(); this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(460, 420); this.Text = "My Profile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.White; this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            this.lblTitle.Text = "My Profile"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(13, 71, 161); this.lblTitle.Location = new System.Drawing.Point(150, 15); this.lblTitle.Size = new System.Drawing.Size(160, 28);

            this.lblRole.Font = new System.Drawing.Font("Segoe UI", 9F); this.lblRole.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblRole.Location = new System.Drawing.Point(30, 50); this.lblRole.Size = new System.Drawing.Size(180, 20);

            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F); this.lblStatus.ForeColor = System.Drawing.Color.Green;
            this.lblStatus.Location = new System.Drawing.Point(250, 50); this.lblStatus.Size = new System.Drawing.Size(150, 20);

            int lx = 30, tx = 180, w = 240;
            SetRow(this.lblName, "Full Name", this.txtName, lx, tx, w, 90);
            SetRow(this.lblEmail, "Email", this.txtEmail, lx, tx, w, 135); this.txtEmail.ReadOnly = true; this.txtEmail.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            SetRow(this.lblPhone, "Phone", this.txtPhone, lx, tx, w, 180);
            SetRow(this.lblAddress, "Address", this.txtAddress, lx, tx, w, 225);

            this.btnSave.Text = "Save Profile"; this.btnSave.Location = new System.Drawing.Point(30, 300); this.btnSave.Size = new System.Drawing.Size(130, 36);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(13, 71, 161); this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnSave.FlatAppearance.BorderSize = 0; this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand; this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnChangePassword.Text = "Change Password"; this.btnChangePassword.Location = new System.Drawing.Point(170, 300); this.btnChangePassword.Size = new System.Drawing.Size(140, 36);
            this.btnChangePassword.BackColor = System.Drawing.Color.DarkOrange; this.btnChangePassword.ForeColor = System.Drawing.Color.White;
            this.btnChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnChangePassword.FlatAppearance.BorderSize = 0; this.btnChangePassword.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChangePassword.Cursor = System.Windows.Forms.Cursors.Hand; this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);

            this.btnClose.Text = "Close"; this.btnClose.Location = new System.Drawing.Point(320, 300); this.btnClose.Size = new System.Drawing.Size(100, 36);
            this.btnClose.BackColor = System.Drawing.Color.LightGray; this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand; this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblRole, this.lblStatus, this.lblName, this.txtName, this.lblEmail, this.txtEmail, this.lblPhone, this.txtPhone, this.lblAddress, this.txtAddress, this.btnSave, this.btnChangePassword, this.btnClose });
            this.ResumeLayout(false);
        }
        private void SetRow(System.Windows.Forms.Label lbl, string text, System.Windows.Forms.TextBox txt, int lx, int tx, int w, int y)
        {
            lbl.Text = text; lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); lbl.Location = new System.Drawing.Point(lx, y + 3); lbl.Size = new System.Drawing.Size(140, 20);
            txt.Location = new System.Drawing.Point(tx, y); txt.Size = new System.Drawing.Size(w, 26); txt.Font = new System.Drawing.Font("Segoe UI", 10F); txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        }
        private System.Windows.Forms.Label lblTitle, lblRole, lblStatus, lblName, lblEmail, lblPhone, lblAddress;
        private System.Windows.Forms.TextBox txtName, txtEmail, txtPhone, txtAddress;
        private System.Windows.Forms.Button btnSave, btnChangePassword, btnClose;
    }
}
