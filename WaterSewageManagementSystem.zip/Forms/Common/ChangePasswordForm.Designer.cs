namespace WaterSewageManagementSystem.Forms.Common
{
    partial class ChangePasswordForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblOld = new System.Windows.Forms.Label(); this.txtOld = new System.Windows.Forms.TextBox();
            this.lblNew = new System.Windows.Forms.Label(); this.txtNew = new System.Windows.Forms.TextBox();
            this.lblConfirm = new System.Windows.Forms.Label(); this.txtConfirm = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button(); this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(400, 280);
            this.Text = "Change Password"; this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.White; this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            this.lblTitle.Text = "Change Password"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(13, 71, 161); this.lblTitle.Location = new System.Drawing.Point(100, 15); this.lblTitle.Size = new System.Drawing.Size(200, 28);

            SetRow(this.lblOld, "Current Password", this.txtOld, 60);
            SetRow(this.lblNew, "New Password", this.txtNew, 110);
            SetRow(this.lblConfirm, "Confirm New Password", this.txtConfirm, 160);
            this.txtOld.PasswordChar = '*'; this.txtNew.PasswordChar = '*'; this.txtConfirm.PasswordChar = '*';

            this.btnSave.Text = "Save"; this.btnSave.Location = new System.Drawing.Point(30, 215); this.btnSave.Size = new System.Drawing.Size(155, 36);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(13, 71, 161); this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnSave.FlatAppearance.BorderSize = 0; this.btnSave.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand; this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnCancel.Text = "Cancel"; this.btnCancel.Location = new System.Drawing.Point(215, 215); this.btnCancel.Size = new System.Drawing.Size(155, 36);
            this.btnCancel.BackColor = System.Drawing.Color.LightGray; this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand; this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblOld, this.txtOld, this.lblNew, this.txtNew, this.lblConfirm, this.txtConfirm, this.btnSave, this.btnCancel });
            this.ResumeLayout(false);
        }
        private void SetRow(System.Windows.Forms.Label lbl, string text, System.Windows.Forms.TextBox txt, int y)
        {
            lbl.Text = text; lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); lbl.Location = new System.Drawing.Point(30, y); lbl.Size = new System.Drawing.Size(160, 20);
            txt.Location = new System.Drawing.Point(200, y - 2); txt.Size = new System.Drawing.Size(170, 26); txt.Font = new System.Drawing.Font("Segoe UI", 10F); txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        }
        private System.Windows.Forms.Label lblTitle, lblOld, lblNew, lblConfirm;
        private System.Windows.Forms.TextBox txtOld, txtNew, txtConfirm;
        private System.Windows.Forms.Button btnSave, btnCancel;
    }
}
