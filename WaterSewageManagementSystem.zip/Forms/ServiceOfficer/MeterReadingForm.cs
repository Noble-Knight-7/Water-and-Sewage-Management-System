using System;
using System.Windows.Forms;
using WaterSewageManagementSystem.Helpers;
using WaterSewageManagementSystem.Models;
using WaterSewageManagementSystem.Services;

namespace WaterSewageManagementSystem.Forms.ServiceOfficer
{
    public partial class MeterReadingForm : Form
    {
        private readonly BillingService _billingService = new BillingService();

        public MeterReadingForm()
        {
            InitializeComponent();
            // Load customer list into combo box
            cmbCustomer.DataSource    = _billingService.GetAllCustomers();
            cmbCustomer.DisplayMember = "FullName";
            cmbCustomer.ValueMember   = "CustomerID";
            // Set billing month default to current month
            txtBillingMonth.Text = DateTime.Now.ToString("MMMM yyyy");
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (cmbCustomer.SelectedItem == null)
            {
                MessageHelper.ShowError("Please select a customer."); return;
            }
            if (!decimal.TryParse(txtPrevious.Text, out decimal prev) ||
                !decimal.TryParse(txtCurrent.Text,  out decimal curr))
            {
                MessageHelper.ShowError("Enter valid numeric meter readings."); return;
            }
            if (curr < prev)
            {
                MessageHelper.ShowError("Current reading cannot be less than previous reading."); return;
            }
            if (ValidationHelper.IsEmpty(txtBillingMonth.Text))
            {
                MessageHelper.ShowError("Enter billing month."); return;
            }

            decimal arrears = decimal.TryParse(txtArrears.Text, out decimal a) ? a : 0;
            int customerID  = (int)cmbCustomer.SelectedValue;

            bool success = _billingService.GenerateBill(customerID, txtBillingMonth.Text.Trim(), prev, curr, arrears);
            if (success)
            {
                decimal units  = curr - prev;
                decimal amount = units * 8; // 8 taka per unit
                MessageHelper.ShowSuccess($"Bill generated!\nUnits used: {units}\nAmount: ৳{amount:N2}\nArrears: ৳{arrears:N2}\nTotal Due: ৳{amount + arrears:N2}");
                txtPrevious.Clear(); txtCurrent.Clear(); txtArrears.Text = "0";
            }
            else MessageHelper.ShowError("Failed to generate bill. Please check the readings.");
        }

        private void btnClose_Click(object sender, EventArgs e) => this.Close();
    }
}
