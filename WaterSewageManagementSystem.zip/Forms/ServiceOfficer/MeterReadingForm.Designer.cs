namespace WaterSewageManagementSystem.Forms.ServiceOfficer
{
    partial class MeterReadingForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle        = new System.Windows.Forms.Label();
            this.lblCustomer     = new System.Windows.Forms.Label(); this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.lblMonth        = new System.Windows.Forms.Label(); this.txtBillingMonth = new System.Windows.Forms.TextBox();
            this.lblPrevious     = new System.Windows.Forms.Label(); this.txtPrevious = new System.Windows.Forms.TextBox();
            this.lblCurrent      = new System.Windows.Forms.Label(); this.txtCurrent = new System.Windows.Forms.TextBox();
            this.lblArrears      = new System.Windows.Forms.Label(); this.txtArrears = new System.Windows.Forms.TextBox();
            this.btnGenerate     = new System.Windows.Forms.Button();
            this.btnClose        = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(500, 370); this.Text = "Enter Meter Reading & Generate Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen; this.BackColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            this.lblTitle.Text = "Meter Reading & Bill Generation"; this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(21,101,192); this.lblTitle.Location = new System.Drawing.Point(60, 12); this.lblTitle.Size = new System.Drawing.Size(380, 28);

            int lx = 30, tx = 210, w = 240, y = 55;
            Row(lblCustomer, "Customer:", cmbCustomer, lx, tx, w, y);
            y += 48; Row(lblMonth, "Billing Month:", txtBillingMonth, lx, tx, w, y);
            y += 48; Row(lblPrevious, "Previous Reading:", txtPrevious, lx, tx, w, y);
            y += 48; Row(lblCurrent,  "Current Reading:",  txtCurrent,  lx, tx, w, y);
            y += 48; Row(lblArrears,  "Arrears (৳):",      txtArrears,  lx, tx, w, y);
            txtArrears.Text = "0";

            y += 55;
            this.btnGenerate.Text = "Generate Bill"; this.btnGenerate.Location = new System.Drawing.Point(lx, y); this.btnGenerate.Size = new System.Drawing.Size(160, 40);
            this.btnGenerate.BackColor = System.Drawing.Color.FromArgb(0,105,92); this.btnGenerate.ForeColor = System.Drawing.Color.White;
            this.btnGenerate.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnGenerate.FlatAppearance.BorderSize = 0; this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);

            this.btnClose.Text = "Close"; this.btnClose.Location = new System.Drawing.Point(370, y); this.btnClose.Size = new System.Drawing.Size(100, 40);
            this.btnClose.BackColor = System.Drawing.Color.Gray; this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat; this.btnClose.FlatAppearance.BorderSize = 0; this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblCustomer, this.cmbCustomer, this.lblMonth, this.txtBillingMonth, this.lblPrevious, this.txtPrevious, this.lblCurrent, this.txtCurrent, this.lblArrears, this.txtArrears, this.btnGenerate, this.btnClose });
            this.ResumeLayout(false);
        }
        private void Row(System.Windows.Forms.Label lbl, string text, System.Windows.Forms.Control ctrl, int lx, int tx, int w, int y)
        {
            lbl.Text = text; lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); lbl.Location = new System.Drawing.Point(lx, y+4); lbl.Size = new System.Drawing.Size(175, 22);
            ctrl.Location = new System.Drawing.Point(tx, y); ctrl.Size = new System.Drawing.Size(w, 26); ctrl.Font = new System.Drawing.Font("Segoe UI", 10F);
            if (ctrl is System.Windows.Forms.TextBox txt) txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            if (ctrl is System.Windows.Forms.ComboBox cmb) cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }
        private System.Windows.Forms.Label lblTitle, lblCustomer, lblMonth, lblPrevious, lblCurrent, lblArrears;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.TextBox txtBillingMonth, txtPrevious, txtCurrent, txtArrears;
        private System.Windows.Forms.Button btnGenerate, btnClose;
    }
}
